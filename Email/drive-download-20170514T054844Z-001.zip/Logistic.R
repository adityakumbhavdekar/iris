library(caret)
library(LogisticDx)
library(car)

data<-read.csv(file.choose())
str(data)
data$IncomeGrp<-as.factor(data$IncomeGrp)
data$Family_doctor<-as.factor(data$Family_doctor)

data1<-data[,c(2,9,10,12,13,14)]
correlation<-cor(data1,data1)
correlation

VarInf<-vif(lm(Responder~Age+No.of.prod1+MSL_prod1+No.of.prod2+MSL_prod2+num_of_cars,data=data))
VarInf

data$Responder<-as.factor(data$Responder)
str(data)

Index<-createDataPartition(data$Responder,p=0.8,list=FALSE,times=1)
DataTrain<-data[Index,]
DataTest<-data[-Index,]

UpTrain<-upSample(x=DataTrain[,-1],y=as.factor(DataTrain$Responder),yname="Responder")
table(UpTrain$Responder)

model<-glm(Responder~Age+Channel+FS_code+Marital_status+Gender+Prosperity_Index+
      IncomeGrp+No.of.prod1+MSL_prod1+MR_prod+No.of.prod2+MSL_prod2+num_of_cars+Family_doctor,
      family=binomial(link='logit'),data=UpTrain)

summary(model)

goodness<-gof(model,plotROC=TRUE)
Deviance<-anova(model,test="Chisq")
Deviance

fitted.train<-predict(model,newdata=UpTrain,type='response')
fitted.train<-ifelse(fitted.train > 0.5,1,0)
confusionMatrix(fitted.train,UpTrain$Responder,positive="1")


fitted.test<-predict(model,newdata=DataTest,type='response')
fitted.test<-ifelse(fitted.test > 0.5,1,0) 
confusionMatrix(fitted.test,DataTest$Responder,positive="1")




